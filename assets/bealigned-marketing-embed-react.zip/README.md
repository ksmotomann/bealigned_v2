# BeAligned Marketing Embed (React SPA)

This provides a React Router–ready replacement for your landing page:
`src/pages/LandingPage.tsx`

It embeds your public Figma site at https://bealigned.figma.site/ and adds a fixed header
with **Log in / Get started** buttons that both link to `/auth` (your existing route).

## Install

1) **Back up** your current landing page:
   - Copy `src/pages/LandingPage.tsx` to `backups/landing-YYYYMMDD-HHMMSS.tsx`

2) Replace the file:
   - Overwrite `src/pages/LandingPage.tsx` with the file from this archive.

3) Deploy to Vercel as usual.

## Safety notes
- This change only touches the landing page component.
- It does not modify your `/auth` route or any other app routes.

## Optional assets
`public/favicon.svg` and `public/og.png` are included as placeholders if you want to update branding.
