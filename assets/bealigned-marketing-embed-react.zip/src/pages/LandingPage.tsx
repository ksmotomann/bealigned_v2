import React from "react";

const FIGMA_URL = "https://bealigned.figma.site/";

export default function LandingPage() {
  return (
    <div style={{ width: "100vw", height: "100vh", margin: 0 }}>
      {/* Fixed header with real links */}
      <header
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          height: 64,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 20px",
          zIndex: 10,
          background: "rgba(255,255,255,0.8)",
          backdropFilter: "blur(8px)",
          WebkitBackdropFilter: "blur(8px)",
          borderBottom: "1px solid rgba(0,0,0,0.06)",
        }}
      >
        <a href="/" style={{ fontWeight: 700, textDecoration: "none", color: "#111" }}>
          BeAligned
        </a>
        <nav style={{ display: "flex", gap: 12 }}>
          <a href="/auth" style={{ textDecoration: "none", color: "#111" }}>
            Log in
          </a>
          <a
            href="/auth"
            style={{
              textDecoration: "none",
              padding: "8px 14px",
              borderRadius: 999,
              border: "1px solid rgba(0,0,0,0.12)",
            }}
          >
            Get started
          </a>
        </nav>
      </header>

      {/* Figma site embedded full-viewport */}
      <iframe
        title="BeAligned prototype"
        src={FIGMA_URL}
        style={{ border: "0", width: "100%", height: "100%" }}
        allowFullScreen
      />
    </div>
  );
}
